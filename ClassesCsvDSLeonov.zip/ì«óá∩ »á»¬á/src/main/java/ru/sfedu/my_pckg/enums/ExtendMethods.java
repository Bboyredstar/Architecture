package ru.sfedu.my_pckg.enums;

public enum ExtendMethods {
    RATING,
    COMMENTS,
    UPDATE,
    DELETE,
    CREATE,
    JOIN,
    REVIEW
}
