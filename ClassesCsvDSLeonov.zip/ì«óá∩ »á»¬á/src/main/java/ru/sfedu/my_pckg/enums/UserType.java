package ru.sfedu.my_pckg.enums;

public enum UserType {
    TEACHER,
    STUDENT
}
